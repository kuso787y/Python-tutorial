import requests
import Config
import FinMind
from Database import Postgres
from Initial import log_setting
import pandas as pd
import time

logger = log_setting.logger


class Fin:

    def __init__(self):
        self.engine = Config.create_ng()
        self.url = FinMind.api()
        self.date = Config.txdate()
        # self.pool = Postgres.get("select stock_id from stock_info order by stock_id asc;")
        self.pool = Postgres.get("select stock_id from stock_info where stock_id >= '3171' order by stock_id;")

    def taiwanstockprice(self):
        logger.info(__name__)
        for i in self.pool:
            sid = i[0]
            logger.info('get {} information'.format(sid))
            Postgres.run("delete from stock_price_new where stock_id = '{}' and date = '{}';".format(sid, self.date))
            payload = {'dataset': 'TaiwanStockPrice', 'stock_id': sid, 'date': self.date}
            res = requests.post(self.url, verify=True, data=payload)
            temp = res.json()
            data = pd.DataFrame(temp['data'])
            data.to_sql(name='stock_price_new', con=self.engine, if_exists='append', index=False)
            time.sleep(20)

    def financialstatements(self):
        logger.info(__name__)
        for i in self.pool:
            sid = i[0]
            # logger.info('get FinancialStatements: {}'.format(sid))
            Postgres.run("delete from stock_price_new where stock_id = '{}' and date = '{}';".format(sid, self.date))
            payload = {'dataset': 'FinancialStatements', 'stock_id': sid, 'date': self.date}
            res = requests.post(self.url, verify=True, data=payload)
            temp = res.json()
            data = pd.DataFrame(temp['data'])
            data.to_sql(name='stock_fin_stat', con=self.engine, if_exists='append', index=False)
            time.sleep(10)
