from Initial import log_setting
from WebCrawler.crawler import Fin
import FinMind


if __name__ == '__main__':
    logger = log_setting.logger
    logger.info('hello')
    Fin().taiwanstockprice()
    logger.info('bye~~~~~~~~~~~~~~~')
