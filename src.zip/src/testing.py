from sqlalchemy import create_engine
from Database import Postgres
import datetime

# engine = create_engine('postgresql://postgres:postgres@localhost:5432/stock')


def create():
    engine = create_engine(r'postgresql://postgres:postgres@localhost:5432/stock')
    return engine


def tp():
    return 1, 2

d = datetime.date.strftime(datetime.datetime.now(), '%Y-%m-%d')
print(d)
print(type(d))
