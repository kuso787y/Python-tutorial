from Initial import log_setting
from sqlalchemy import create_engine


logger = log_setting.logger


def create_ng():
    logger.info('configure database settings for pandas')
    engine = create_engine(r'postgresql://postgres:postgres@localhost:5432/stock')
    return engine


def txdate():
    d = '2020-03-27'
    logger.info('txdate is {}'.format(d))
    return d

